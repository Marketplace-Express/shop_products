create trigger trigger_log_update
  after UPDATE
  on product
  for each row
BEGIN
  INSERT INTO admins_logs (action, user_id, product_id, action_data, done_at)
  VALUES
  ('UPDATE',
   new.product_user_id,
   new.product_id,
   json_object(
       'old_product_title', old.product_title,
       'old_product_category_id', old.product_category_id,
       'old_product_type', old.product_type,
       'old_product_custom_page_id', old.product_custom_page_id,
       'product_title', new.product_title,
       'product_category_id', new.product_category_id,
       'product_type', new.product_type,
       'product_custom_page_id', new.product_custom_page_id,
       'is_deleted', new.is_deleted,
       'deleted_at', new.deleted_at
     ),
   now());
END;

